
public interface Test {
	
	public boolean run();

}
