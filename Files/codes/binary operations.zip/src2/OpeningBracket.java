
public class OpeningBracket extends CalcToken {

	public String toString() {
		return "(";
	}
}
