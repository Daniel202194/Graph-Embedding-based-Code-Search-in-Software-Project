
public class ClosingBracket extends CalcToken {
	public String toString() {
		return ")";
	}
}
