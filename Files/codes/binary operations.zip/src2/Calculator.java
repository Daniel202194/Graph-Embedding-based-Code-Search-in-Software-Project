
public interface Calculator {
	
	public double evaluate(String expr);
}
